Per-image segmentation metrics for 100 training runs.

Four arms x five architectures x five folds:
  clinicdb_random         random frame splits of CVC-ClinicDB
  clinicdb_seqdisjoint    splits respecting the 29 official sequences
  kvasir_imagelevel       image-level folds of Kvasir-SEG
  kvasir_grouped_tau0.90  folds grouping near-duplicates

Each row is one image under one trained model. The 'dataset' column
gives the test set; '-ext' marks a zero-shot external set. Images are
identified by filename so rows can be joined to the original data,
which is not redistributed here.
